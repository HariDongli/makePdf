export interface ICountryListModel {
  name: string;
  code: string;
}
