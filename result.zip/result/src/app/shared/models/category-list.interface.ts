export interface ICategoryListInterface {
  name: string;
  id: number;
}
