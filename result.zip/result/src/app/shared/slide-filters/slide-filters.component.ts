import { Component, OnInit, Input } from '@angular/core';
import { FormControl } from '@angular/forms';

import { appConfig } from 'appConfig';
import { ICountryListModel } from '@shared/models/country-list.interface';
import { ICategoryListInterface } from '@shared/models/category-list.interface';
import { ContextService } from '@shared/context.service';
import { Observable, Subject } from 'rxjs';
import { map, catchError, merge, startWith } from 'rxjs/internal/operators';
import { throwError } from 'rxjs/index';
import { YoutubeService } from "@modules/youtube/service/youtube.service";

@Component({
  selector: 'app-slide-filters',
  templateUrl: './slide-filters.component.html',
  styleUrls: ['./slide-filters.component.scss'],
})
export class SlideFiltersComponent implements OnInit {
  @Input() public filterSlide: any;
  public countryFormControl: FormControl = new FormControl();
  public countryList: ICountryListModel[] = appConfig.countryList;
  public countryListObs: Observable<any>;
  public categoryFormControl: FormControl = new FormControl();
  public categoriesList: ICategoryListInterface[] = [
    { name: 'Film & Animation', id: 1 },
    { name: 'Autos & Vehicles', id: 2 },
    { name: 'Music', id: 10 },
    { name: 'Pets & Animals', id: 4 }
  ];
  public categoriesListObs: Observable<any>;

  public defaultVideosOnPage: number = localStorage.getItem('videosPerPage')===undefined? appConfig.maxVideosToLoad : parseInt(localStorage.getItem('videosPerPage'));

  constructor(private appContext: ContextService, private youtubeservice: YoutubeService) {
    this.youtubeservice.getCategoryList().pipe(map(data => {
       data.items.map(item => { item.name = item.snippet.title; });
       return data.items; }))
       .subscribe((res: ICategoryListInterface[]) => {
        this.categoriesList.splice(0,this.categoriesList.length);
        this.categoriesList = res;
        this.setDefaults();
      }
      )
    this.categoriesListObs = this.categoryFormControl.valueChanges
      .pipe(
      startWith(''),
      map(cat => cat ? this._filterValues(cat, this.categoriesList) : this.categoriesList.slice())
      );
    this.countryListObs = this.countryFormControl.valueChanges
      .pipe(
      startWith(''),
      map(cnty => cnty ? this._filterValues(cnty, this.countryList) : this.countryList.slice())
      );
  }

  private _filterValues(value: string, arrayVal) {
    const filterValue = value.toLowerCase();
    return arrayVal.filter(cnty => cnty.name.toLowerCase().indexOf(filterValue) === 0);
  }

  public ngOnInit() {
    // this.setDefaults();
  }

  public onChangeVideosPerPage(count: number) {
    this.appContext.videosCountPerPage.next(count);
  }
  public onChangeCountry( val){
   const code =  this.countryList.find(country => country.name === val).code;
   this.appContext.selectedCountry.next(code);
  }
    public onChangeCategory( val){
    const id = this.categoriesList.find( cat => cat.name === val).id.toString();
    this.appContext.selectedCategory.next(id);
  }

  private setDefaults() {
    const ccode = localStorage.getItem('regionCode')===undefined? appConfig.defaultRegion: localStorage.getItem('regionCode');
    const defaultCountry = this.countryList.find((country) =>
      country.code === ccode ).name;
    const dcat = localStorage.getItem('videoCategoryId')===undefined? appConfig.defaultCategoryId: localStorage.getItem('videoCategoryId');
    const defaultCategory = this.categoriesList.find((country) => country.id == dcat).name
    this.countryFormControl.setValue(defaultCountry);
    this.categoryFormControl.setValue(defaultCategory);
  }
}
