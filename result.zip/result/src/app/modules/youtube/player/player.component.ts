import { Component, OnInit } from '@angular/core';

import { appConfig } from 'appConfig';
import { ContextService } from "@shared/context.service";
import { OnDestroy } from "@angular/core";

@Component({
  selector   : 'app-player',
  templateUrl: './player.component.html',
  styleUrls  : [ './player.component.scss' ]
})
export class PlayerComponent implements OnInit ,OnDestroy{
  public embedUrl: string;
  public videoLoader: boolean;
  constructor(private cs: ContextService){
    this.cs.showHeader.next(false);
  }
  public ngOnInit() {
    const id = window.location.href
                     .replace(/^.*\//g, '')
                     .replace(/^.*\..*/g, '');
    if (!id.length) {
      return;
    }
    this.videoLoader = false;
    this.embedUrl = appConfig.getYoutubeEmbdedUrl(id);
  }
    public ngOnDestroy(){
    this.cs.showHeader.next(true);
    }

  /* On video ready hide loader */
  public loadVideo(): void {
    this.videoLoader = true;
  }

}
