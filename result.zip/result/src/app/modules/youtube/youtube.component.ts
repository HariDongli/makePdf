import { Component, OnInit } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { map,catchError ,merge} from 'rxjs/internal/operators';
import { throwError } from 'rxjs/index';
import { combineLatest } from 'rxjs/observable/combineLatest';
import { YoutubeService } from './service/youtube.service';
import { ContextService } from '@shared/context.service';
import { VideoClass } from './models/video.class';
import { concat } from "rxjs/internal/observable/concat";

@Component({
  selector   : 'app-youtube-component',
  templateUrl: './youtube.component.html',
  styleUrls  : [ './youtube.component.scss' ]
})

export class YoutubeComponent implements OnInit {
  public trendingVideos : Observable<VideoClass[]> ;
  public trendingVideosArray: VideoClass[] = [];
  public tv: Observable<VideoClass[]>
  public loadingError$ = new Subject<boolean>();
  public videos: VideoClass[];
  public pt ;
  constructor(private youtubeService: YoutubeService,
              private appContext: ContextService) {
  }
  
  public ngOnInit(): void {
    this.appContext.moduleTitle.next('YOUTUBE');
    this.loadVideos();
    this.appContext.videosCountPerPage.subscribe((count) => this.loadVideos(count));
    this.appContext.selectedCountry.subscribe((country)=> this.loadVideos( undefined, country))
    this.appContext.selectedCategory.subscribe((category)=> this.loadVideos( undefined, undefined,category))
  }

  private loadVideos(videosPerPage?: number, regionCode?: string, catid?: string) {
    let vpp = 0;
    if(videosPerPage)
      localStorage.setItem('videosPerPage', videosPerPage.toString());
    else {
      videosPerPage = parseInt(localStorage.getItem('videosPerPage'));
    }
    let vppi = videosPerPage;    
    if(videosPerPage <=50 || videosPerPage ===undefined){
    this.trendingVideos  = this.youtubeService.getTrendingVideos(videosPerPage, undefined,regionCode,catid)
                              .pipe(
                                 map(
                      (data :any ) =>  { 
                              return data.items
                                  .map((item) => new VideoClass(item))
                                 .filter((item) => item.id !== '')
                            }
                                ),
                                catchError((error: any) => {
                                  this.loadingError$.next(true);
                                  return throwError(error);
                                })
                              );
    }
    else{
      this.trendingVideos = new Observable<VideoClass[]>();
      let result: Observable<VideoClass[]>  = new Observable<VideoClass[]>();
      this.pt= undefined;
    while(vppi >= 0){
      let res: Observable<VideoClass[]>;
      const val = vppi > 50 ? 50: vppi;
      res = this.youtubeService.getTrendingVideos(val,this.pt,regionCode,catid)
                              .pipe(
                                 map(
                      (data :any ) =>  {
                            this.pt = data.nextPageToken
                             return data.items
                                  .map((item) => new VideoClass(item))
                                 .filter((item) => item.id !== '')}
                                ),
                                catchError((error: any) => {
                                  this.loadingError$.next(true);
                                  return throwError(error);
                                })
                              );
      result = concat(res,result);
      vppi -= 50;
    }
    this.trendingVideos  = result;
    }
  this.trendingVideosArray=[];
  this.trendingVideos.subscribe(res => {
      this.trendingVideosArray.push(...res);
    })
  }

}
