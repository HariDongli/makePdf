import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/internal/operators';

import { appConfig } from 'appConfig';
import { VideoClass } from '../models/video.class';

@Injectable()
export class YoutubeService {

  constructor(private http: HttpClient) {
    if(localStorage.getItem('videosPerPage')===undefined)
    localStorage.setItem('videosPerPage', appConfig.maxVideosToLoad.toString());
    if(localStorage.getItem('regionCode')===undefined)
    localStorage.setItem('regionCode',appConfig.defaultRegion)
    if(localStorage.getItem('videoCategoryId')===undefined)
    localStorage.setItem('videoCategoryId',appConfig.defaultCategoryId.toString());
  }

  public getTrendingVideos(videosPerPage?: number, pageToken?: string, regionCode?: string, catid?: string): Observable<VideoClass[]> {
    console.log('hello')
    if(regionCode)
       localStorage.setItem('regionCode',regionCode)
    if(catid)
       localStorage.setItem('videoCategoryId',catid)
    const params: any = {
      part           : appConfig.partsToLoad,
      chart          : appConfig.chart,
      videoCategoryId: localStorage.getItem('videoCategoryId'),
      regionCode     : localStorage.getItem('regionCode'),
      maxResults     : videosPerPage ? videosPerPage : appConfig.maxVideosToLoad,
      key            : appConfig.youtubeApiKey,
    };
    if(pageToken) {
      params.pageToken = pageToken;
    }
    return this.http.get<any>(appConfig.getYoutubeEndPoint('videos'), {params})
               .pipe(
                 catchError(this.handleError('getTrendingVideos'))
               ) as Observable<VideoClass[]>;
  }

  private handleError(operation: string = 'operation') {
    return (error: any) => {
      error.operation = operation;
      return throwError(error);
    };
  }
  public getCategoryList(regionCode? : string){
  //  const url =   "https://www.googleapis.com/youtube/v3/videoCategories?&key=AIzaSyCCwLsO1Z8-ubGs-qPjjNjaOK0WhaVY4UM";
   const params:any = {
    part: "snippet",
    regionCode: regionCode? regionCode:appConfig.defaultRegion,
    key: appConfig.youtubeApiKey
   }
   return this.http.get<any>(appConfig.getYoutubeEndPoint('videoCategories'),{params});
  }
}
