import { SafeSanPipe } from './safe-san.pipe';

describe('SafeSanPipe', () => {
  it('create an instance', () => {
    const pipe = new SafeSanPipe();
    expect(pipe).toBeTruthy();
  });
});
